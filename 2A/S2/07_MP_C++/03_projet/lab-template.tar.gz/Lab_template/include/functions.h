#ifndef FUNCTIONS_H
#define FUNCTIONS_H

inline int int_addition(int a, int b) {
  int c = a + b;
  return c;
}
#endif
