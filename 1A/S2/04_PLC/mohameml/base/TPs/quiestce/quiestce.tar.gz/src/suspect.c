#include "suspect.h"

struct suspect *creer_suspect(const char *name, ensemble_t attributs)
{
    return 0;
}

struct liste_suspects *creer_liste_suspects(void)
{
    return 0;
}

void detruire_liste_suspects(struct liste_suspects **pl)
{
}

void ajouter_suspect(struct liste_suspects *liste, struct suspect *suspect)
{
}

void retirer_suspect(struct liste_suspects *liste, struct suspect *suspect)
{
}

void affiche_liste_suspects(struct liste_suspects *l)
{
}
