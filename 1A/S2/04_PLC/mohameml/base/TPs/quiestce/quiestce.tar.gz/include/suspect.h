#ifndef SUSPECT_H
#define SUSPECT_H

#include "ensemble.h"

/* Suspect du jeu Qui est-ce. */
struct suspect {
    char *nom;
    ensemble_t attributs;
    struct suspect *suiv;
    struct suspect *prec;
};

/* Liste doublement chainee de suspects. */
struct liste_suspects {
    uint16_t nb_suspects;
    struct suspect *tete;
    struct suspect *queue;
};

/* Retourne un nouveau suspect initialise en fonction des parametres
 * nom et attributs. */
extern struct suspect *creer_suspect(const char *nom, ensemble_t attributs);

/* Cree une nouvelle liste de suspects, initialement vide. */
extern struct liste_suspects *creer_liste_suspects(void);

/* Detruit la liste de suspects passee en parametre. */
extern void detruire_liste_suspects(struct liste_suspects **pl);

/* Ajoute le suspect s en fin de la liste de suspects l. */
extern void ajouter_suspect(struct liste_suspects *l, struct suspect *s);

/* Retire le suspect s de la liste de suspects l. */
extern void retirer_suspect(struct liste_suspects *l, struct suspect *s);

/* Affiche les noms de tous les suspects de la liste l. */
extern void affiche_liste_suspects(struct liste_suspects *l);

#endif /* SUSPECT_H */
