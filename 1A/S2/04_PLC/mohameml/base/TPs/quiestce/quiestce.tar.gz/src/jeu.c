#include <stdlib.h>
#include "jeu.h"

int main(void)
{
    return EXIT_SUCCESS;
}
